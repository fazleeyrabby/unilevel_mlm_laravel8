<?php

namespace App\Http\Controllers\Dealer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Bonus;
use Auth;

class DashboardController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */

    public function dashboard()
    {
        $earnings = Bonus::with('user')->where('user_id',Auth::user()->id)->orderBy('bonus_id','desc')->take(10)->get();
        return view('dealer.dashboard',compact('earnings'));
    }

    public function dashboard2()
    {

        return view('dealer.dashboard2');
    }

    /**
     * Show blank page.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function blank()
    {
        return view('dealer.blank');
    }
}
