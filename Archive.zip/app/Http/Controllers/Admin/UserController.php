<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Illuminate\Validation\Rule;
use App\Rules\CheckParent;
use App\Rules\CheckPackage;
use App\Rules\CheckDealer;
use App\Models\User;
use App\Models\Package;
use App\Models\Bonus;
use Hash;
use Auth;
use DB;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function index()
    {
        
        $users = User::all();
        return view('admin.users', compact('users'));
    }

     /**
     * Display user profile.
     *
     * @return \Illuminate\Http\Response
     */
    public function profile($id)
    {   
        
        $id = base64_decode($id)/ Auth::user()->id;
        $user = User::findOrFail($id);
        $parent = User::find($user->parent_id);
        $sponsor = User::find($user->sponsor_id);
        $dealer  = $this->getUserBy(['dealer_code' => $user->dealer_code]);
        return view('admin.users.profile', compact('user','parent','sponsor','dealer'));
    }


    /**
     * Display user referral.
     *
     * @return \Illuminate\Http\Response
     */
    public function referral($id)
    {   
        
        $id = base64_decode($id)/ Auth::user()->id;
        $user = User::findOrFail($id);
        $users = User::where(['sponsor_id' => $id])->get();
        return view('admin.users.referral', compact('user','users'));
    }

     /**
     * Display user bonus.
     *
     * @return \Illuminate\Http\Response
     */
    public function bonus($id)
    {   
        
        $id = base64_decode($id)/ Auth::user()->id;
        $user = User::findOrFail($id);
        $bonus = Bonus::with('user')->where(['user_id' => $id])->get();
        return view('admin.users.bonus', compact('user','bonus'));
    }

    public function contact_update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|max:255',
            'email' => 'required',
            'phone' => 'required',
            'thana' => 'required',
            'district' => 'required',
            'zip_code' => 'required',
            'address' => 'required',
            
        ]);

        $id = base64_decode($id)/ Auth::user()->id;
        $user = User::findOrFail($id);
        $user->name = $request->name;
        $user->email = $request->email;
        $user->phone = $request->phone;
        $user->thana = $request->thana;
        $user->district = $request->district;
        $user->zip_code = $request->zip_code;
        $user->address = $request->address;
        $user->national_id = $request->national_id;
        if($user->save()){
            return redirect('admin/users')->with(['status' => 'success', 'message' => 'Contact info update success!']);
        }
        else{
            return redirect('admin/users')->with(['status' => 'error', 'message' => 'Something went wrong!']);
        }
    }

    

    public function password_update(Request $request, $id)
    {
        $request->validate([
            'password' => 'required',
            'password_confirmation' => 'same:password|required',
        ]);

        $id = base64_decode($id)/ Auth::user()->id;
        $user = User::findOrFail($id);
        $user->password = $request->password;
        if($user->save()){
            return redirect('admin/users')->with(['status' => 'success', 'message' => 'Profile update success!']);
        }
        else{
            return redirect('admin/users')->with(['status' => 'error', 'message' => 'Something went wrong!']);
        }
    }



    public function trans_pass_update(Request $request, $id)
    {
        $request->validate([
            'transaction_password' => 'required',
            'transaction_password_confirmation' => 'required|same:transaction_password',
        ]);

        $id = base64_decode($id)/ Auth::user()->id;
        $user = User::findOrFail($id);
        $user->transaction_password = $request->transaction_password;
        if($user->save()){
            return redirect('admin/users')->with(['status' => 'success', 'message' => 'Transaction password update success!']);
        }
        else{
            return redirect('admin/users')->with(['status' => 'error', 'message' => 'Something went wrong!']);
        }
    }
    

    public function update_role(Request $request, $id)
    {
        $request->validate([
            'role' => 'required',
        ]);

        $dealer_id =  rand(10000,99999);
        $dealer= $this->generateDealerId($dealer_id);
        
        while($dealer){
            $dealer_id =  rand(10000,99999);
            $dealer = $this->generateDealerId($dealer_id);
        }

        $id = base64_decode($id)/ Auth::user()->id;
        $user = User::findOrFail($id);

        if($request->role == 1){
            $user->role = 'dealer';
            if($user->dealer_id == null){
                $user->dealer_id = $dealer_id;
            }
        }else{
            $user->role = 'member';
        }

        if($user->save()){
            return redirect('admin/users')->with(['status' => 'success', 'message' => 'Role update success!']);
        }
        else{
            return redirect('admin/users')->with(['status' => 'error', 'message' => 'Something went wrong!']);
        }

        return $request;
    }

    /**
     * Show the form for new user registration.
     *
     * @return \Illuminate\Http\Response
     */
    public function join()
    {
        $user = User::findOrFail(1);
        $packages = Package::all();
        return view('admin.users.join', compact('user','packages'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'username' => ['required', 'unique:users','min:4'],
            'sponsor' => ['required', new CheckParent()],
            'package' => ['required', new CheckPackage()],
            'parent' => ['required', new CheckParent()],
            'position' =>  [
                'required', 
                Rule::unique('users')
                       ->where('parent_id', $request->parent)
                       ->where('position', $request->position)
            ],
            'dealer_code' => ['required', new CheckDealer()],
            'name' => 'required|max:255',
            'email' => 'required',
            'phone' => 'required',
            'thana' => 'required',
            'district' => 'required',
            'zip_code' => 'required',
            'address' => 'required',
            'password' => 'required:min:6',
            'confirm_password' => 'same:password|required',

            'transaction_password' => 'min:6|required',
            'confirm_transaction_password' => 'same:transaction_password|required',
        ]);

        $sponsor = $this->getUserBy(['username' => $request->sponsor]);
        $parent = $this->getUserBy(['username' => $request->parent]);
        $dealer  = $this->getUserBy(['dealer_code' => $request->dealer_code]);

        $user = new User;
        $user->username = $request->username;
        $user->sponsor_id = $sponsor->id;
        $user->package_id = $request->package;
        $user->parent_id = $parent->id;
        $user->position = $request->position;
        $user->dealer_id = $user->id;
        
        $user->name = $request->name;
        $user->email = $request->email;
        $user->phone = $request->phone;
        $user->thana = $request->thana;
        $user->district = $request->district;
        $user->zip_code = $request->zip_code;
        $user->address = $request->address;
        $user->password = Hash::make($request->password);
        $user->transaction_password = Hash::make($request->transaction_password);

        $user->save();
        $user_id = $user->id;

        $this->paySponsorBonus($request->package, $sponsor->id, $user_id, $sponsor->bonus);
        $this->deductPackagePoint($request->package);
        $this->payBonusByDealerCode($dealer->id, $user_id);
        $this->payGenerationBonus($parent->id,$user_id);

        return redirect('admin/users/'.base64_encode($user_id * Auth::user()->id).'/profile');
    }

    /**
     * Pay 10% sponsor bonus.
     *
     * @param  int  $package_id
     * @param  int  $sponsor_id
     * @param  int  $reference_id // newly created user id
     * 
     */
    
    public function paySponsorBonus($package_id, $sponsor_id, $reference_id, $current_bonus){
        
        $package = Package::find($package_id);
        $amount = ($package->point ) / 10 ;
        $type = 'sponsor';

        $bonus = new Bonus;
        $bonus->user_id = $sponsor_id;
        $bonus->user_balance = $current_bonus + $amount;
        $bonus->amount = $amount;
        $bonus->type = $type;
        $bonus->model =  '';
        $bonus->reference_id = $reference_id;

        $bonus = $bonus->save();
        DB::table('users')->where('id', $sponsor_id)->increment('bonus', $amount);
        return 1;
    }

    /**
     * Deduct package point from auth user to create new user.
     *
     * @param  int  $package_id
     * @return 
     */

    public function deductPackagePoint($package_id){
        $package = Package::find($package_id);
        DB::table('users')->where('id', Auth::user()->id)->decrement('balance', $package->point);
    }

    /**
     * Deduct package point from auth user to create new user.
     *
     * @param  int  $dealer_code
     * @param  int  $reference_id // newly created user id
     * 
     */

    public function payBonusByDealerCode($id, $reference_id){
        $dealer  = User::find($id);
        if($dealer->role == 'sub-dealer'){
            $bonus = new Bonus;
            $bonus->user_id = $dealer->id;
            $bonus->user_balance = $dealer->bonus + 5;
            $bonus->amount = '5';
            $bonus->type = 'sub-dealer';
            $bonus->model =  '';
            $bonus->reference_id = $reference_id;
            $bonus = $bonus->save();
            DB::table('users')->where('id', $dealer->id)->increment('bonus', 5);
        }
        
        $this->findDealerAndPay($dealer->dealer_id, $reference_id);
    }


    /**
     * Deduct package point from auth user to create new user.
     *
     * @param  int  $dealer_id
     * @param  int  $reference_id // newly created user id
     * 
     */

    public function findDealerAndPay($dealer_id, $reference_id){
        $dealer  = $this->getUserBy(['dealer_id' => $dealer_id]);

        $bonus = new Bonus;
        $bonus->user_id = $dealer->id;
        $bonus->user_balance = $dealer->bonus + 2;
        $bonus->amount = '2';
        $bonus->type = 'dealer';
        $bonus->model =  '';
        $bonus->reference_id = $reference_id;
        $bonus = $bonus->save();
        DB::table('users')->where('id', $dealer->id)->increment('bonus', 2);
    }

     /**
     * Display the specified resource.
     *
     * @param  int  $parent_id // parent user id
     *   @param  int user_id //newly created user id
     */

    protected function payGenerationBonus($parent_id, $user_id){
        $ids = [];
        $bonusData = [];
        $i=0;
        $break = 0;
        while($i<10 && $break != 1){
            $parent = $this->getUserBy(['id' => $parent_id]);
            $ids[] = $parent->id;
            if($parent->id == 1){
                $break = 1;
            }
            $bonusData[] = ['user_id' => $parent->parent_id, 'user_balance' => $parent->bonus + 1, 'amount' => 1, 'type' => 'Generation', 'reference_id' => $user_id];
            $i++;
        }
        DB::table('users')->whereIn('id', $ids)->increment('bonus');
        DB::table('bonus')->insert($bonusData);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function getUserBy($array = []){
        return User::where($array)->first();
    }

    public function generateDealerId($dealer_id){
        return $dealer = $this->getUserBy(['dealer_id'=> $dealer_id]);
    }
}

